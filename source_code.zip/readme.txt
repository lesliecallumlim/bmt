File Locations
1.	Boundary: ./app/templates
2.	Controller: ./app/routes.py
3.	Entity: ./app/models.py
4.	Init: ./app/__init__.py 
5.	Test Scripts: ./scripts
